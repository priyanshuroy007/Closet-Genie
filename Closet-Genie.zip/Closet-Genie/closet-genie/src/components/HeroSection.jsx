import React from "react";
import "./HeroSection.css";

const HeroSection = () => {
  return (
    <section className="hero-section">
      <div className="hero-content">
        <h1 className="hero-title">Your AI-Powered Fashion Assistant</h1>
        <p className="hero-description">
          Get personalized outfit recommendations, manage your wardrobe, and stay trendy!
        </p>
        <a href="#get-started" className="cta-button">
          Get Started
        </a>
      </div>
    </section>
  );
};

export default HeroSection;

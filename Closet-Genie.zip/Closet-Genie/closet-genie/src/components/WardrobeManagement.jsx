import React, { useState } from "react";
import "./WardrobeManagement.css";

const WardrobeManagement = () => {
  const [clothes, setClothes] = useState([]);
  //const [fileInput, setFileInput] = useState(null);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setClothes([...clothes, URL.createObjectURL(file)]);
    }
  };

  const handleDelete = (index) => {
    setClothes(clothes.filter((_, i) => i !== index));
  };

  return (
    <section className="wardrobe-management">
      <h2>Your Digital Closet</h2>
      <div className="upload-button">
        <input
          type="file"
          onChange={handleFileUpload}
          accept="image/*"
          style={{ display: "none" }}
          id="upload-input"
        />
         <label htmlFor="upload-input">Upload Clothes</label>
      </div>

      <div className="grid-view">
        {clothes.map((item, index) => (
          <div key={index} className="item">
            <img src={item} alt={`clothing-item-${index}`} className="item-img" />
            <div className="item-actions">
              <button className="delete-btn" onClick={() => handleDelete(index)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default WardrobeManagement;

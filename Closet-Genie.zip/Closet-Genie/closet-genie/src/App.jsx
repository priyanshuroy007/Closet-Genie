import React from "react";
import Header from "./components/Header";  // Import Header Component
import HeroSection from "./components/HeroSection";
import WardrobeManagement from "./components/WardrobeManagement";
import "./App.css";

function App() {
  return (
    <div>
      <Header />
      {/* Other sections will go here */}
      <HeroSection />
      <WardrobeManagement />
    </div>
  );
}

export default App;
